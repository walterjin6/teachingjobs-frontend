
import React, { useState, useEffect, useRef } from 'react'
import { Helmet } from "react-helmet";
import SearchResults from './SearchResults';
import admin from "../utils/admin.json";
import { useParams, useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom'




const Admin2 = () => {

  const handleFormSubmit = (event) => {


    event.preventDefault();
    const a = {}
    if (keyWordRef.current.value.trim()) a.q = keyWordRef.current.value.trim()
    if (locationRef.current.value.trim()) a.l = locationRef.current.value.trim()
    navigate("/jobs/", { state: { q: keyWordRef.current.value.trim(), l: locationRef.current.value.trim() } });
  }

  const [page, setPage] = useState(0);
  const navigate = useNavigate()
  const keyWordRef = useRef('')
  const locationRef = useRef('')

  return (


    <div className="">
      <Helmet>
        <title>Admin and Support Academia Jobs USA</title>
        <meta name="description" content="Working in Admin and Support Academia Jobs USA will provide you the chance to collaborate with a varied and skilled group of individuals while advancing the academic standards and innovative practises of your organisation. " />
        <meta name="keywords" content="Admin and Support Academia Jobs USA, Admin and Support AcademicJobs" />
      </Helmet>
      <div className="blurb text-left py-8 ">
        <h1 className=" font-bold text-lg md:text-2xl py-4 px-7 bg-[#f4a10c] text-white rounded-2xl ">Admin and Support Academia Jobs USA</h1>
        <div className="newLine mb-4">
          <p className="font-semibold"></p>
          <p className="font-semibold"></p>
        </div>
        <div className="newLine">
          <div className="py-4 px-7 rounded-2xl ">

            <p>Admin and Support Academia Jobs USA requires professional experience in academic administration and assistance, jobs will require a diploma or higher certification in business administration or a similar sector. Outstanding interpersonal, organisational, communication, and problem-solving abilities are also required for jobs in academic administration and assistance. Higher education policies, processes, and relevant rules and regulations must be understood by candidates for Admin and Support Academia Jobs USA. </p> </div>
          <div className="newLine mb-2"></div>



          <div className="bg-white flex flex-col  ">
            <h2 className="text-1xl font-bold py-1 px-7 bg-[#f4a10c] text-white rounded-3xl mt-20">Choose Higher Ed Admin and Support Jobs in USA</h2>
            <ul className="mb-8 text-left columns-1 md:columns-4  md:gap-2 py-2 px-7 h-auto w-full text-transform: capitalize">
              {admin.map(({ Title, Name, break1, isBold }, key) => (
                <li className={`flex ${break1 ? 'md:break' : ''} ${isBold ? 'pt-4 font-bold text-[#f4a10c]' : ''}`} key={key}>
                  <Link to={`/admin/${Name?.replace(/\s+/g, '-')}/`}>{Name}</Link>
                </li>
              ))}
            </ul>
            <div className="newLine"></div>
          </div>
        </div>





      </div>



      <div className="container mx-auto px-4 sm:px-6 lg:px-8 mb-4">
        <div className="max-w-screen-xl mx-auto">
          <form className="flex flex-col  gap-2 md:flex-row md:gap-2 mx-18 w-full " onSubmit={handleFormSubmit}>
            <input
              type="text"
              className="text-center md:w-[41%] md:text-left px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="Keyword"
              ref={keyWordRef}
            //defaultValue={name}cc
            />
            <input
              type="text"
              className="text-center md:w-[41%] md:text-left px-4 py-2 border border-gray-300 rounded-md focus:ring-orange-500 focus:border-orange-500"
              placeholder="Location"
              ref={locationRef}
            />
            <button
              className="bg-[#f4a10c] hover:bg-orange-600 text-white py-2 px-6 rounded-md focus:ring-2 focus:ring-orange-300"
              type="submit"
            >
              FIND JOBS
            </button>
          </form>
        </div>
      </div>


      <SearchResults q={{ q: "admin", l: "United States" || 0 }} />
    </div>

  );
};

export default Admin2;